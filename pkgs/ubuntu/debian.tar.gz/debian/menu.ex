?package(stereozoom2):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="stereozoom2" command="/usr/bin/stereozoom2"
