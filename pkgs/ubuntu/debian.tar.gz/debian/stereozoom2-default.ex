# Defaults for stereozoom2 initscript
# sourced by /etc/init.d/stereozoom2
# installed at /etc/default/stereozoom2 by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
